package org.test.editor.core.dto;

public record FolderDTO(Integer folderId,String folderPath, Integer parentFolderId, Integer projectId)
{}
