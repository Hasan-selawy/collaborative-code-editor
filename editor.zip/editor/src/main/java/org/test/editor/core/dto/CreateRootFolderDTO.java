package org.test.editor.core.dto;

public record CreateRootFolderDTO (Integer projectId, String folderName,String folderPath){}
