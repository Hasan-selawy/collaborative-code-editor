package org.test.editor.core.dto;

public record UpdateFileDTO(Integer fileId, String content) {
}
