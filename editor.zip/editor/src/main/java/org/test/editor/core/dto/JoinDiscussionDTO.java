package org.test.editor.core.dto;

public record JoinDiscussionDTO (Integer discussionId)
{
}
