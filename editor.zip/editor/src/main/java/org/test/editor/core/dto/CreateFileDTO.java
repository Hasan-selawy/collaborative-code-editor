package org.test.editor.core.dto;

public record CreateFileDTO(Integer folderId, String fileName) {
}

