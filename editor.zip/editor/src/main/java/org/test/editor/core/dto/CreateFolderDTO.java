package org.test.editor.core.dto;

public record CreateFolderDTO(Integer parentFolderId, String folderName) {
}

