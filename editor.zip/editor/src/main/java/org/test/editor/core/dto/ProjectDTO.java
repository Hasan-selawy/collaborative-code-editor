package org.test.editor.core.dto;


public record ProjectDTO(
     Integer projectId,
     String projectName,
     String projectPath,
     String templateName

)
{}