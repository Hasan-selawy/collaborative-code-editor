package org.test.editor.core.dto;

public record CreatePrimaryFolderDTO(String folderName,Integer projectId) {
}