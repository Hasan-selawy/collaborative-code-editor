package org.test.editor.core.service;


import org.test.editor.core.dto.ProjectTemplateDTO;

import java.util.List;

public interface ProjectTemplateService {
    List<ProjectTemplateDTO> getAll();
}