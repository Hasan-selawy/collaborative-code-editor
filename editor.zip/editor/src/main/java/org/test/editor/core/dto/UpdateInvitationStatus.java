package org.test.editor.core.dto;

public record UpdateInvitationStatus(Integer invitationId, Integer invitationStatusId)
{}