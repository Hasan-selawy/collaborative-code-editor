package org.test.editor.util.constant;

public enum StorageType {
    LOCAL,
    S3,
}
