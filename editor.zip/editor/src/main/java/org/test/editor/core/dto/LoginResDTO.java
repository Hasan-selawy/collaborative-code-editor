package org.test.editor.core.dto;

public record LoginResDTO (UserDTO user,String token){}
