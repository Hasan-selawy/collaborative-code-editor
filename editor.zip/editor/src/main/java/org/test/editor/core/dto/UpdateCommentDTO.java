package org.test.editor.core.dto;

public record UpdateCommentDTO(Integer commentId, Integer lineNum, String content)
{}