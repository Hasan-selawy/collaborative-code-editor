package org.test.editor.core.dto;

public record CreateCommentDTO(Integer userId,String content, Integer discussionId)
{}
