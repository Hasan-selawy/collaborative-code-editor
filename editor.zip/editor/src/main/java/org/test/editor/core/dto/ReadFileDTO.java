package org.test.editor.core.dto;

public record ReadFileDTO(String content,Integer fileId){}
