package org.test.editor.core.dto;

public record ProjectTemplateDTO(
Integer templateId,
String  templateName
){}
