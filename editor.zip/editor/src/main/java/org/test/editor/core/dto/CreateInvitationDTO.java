package org.test.editor.core.dto;

public record CreateInvitationDTO(Integer projectId, Integer userId){}
